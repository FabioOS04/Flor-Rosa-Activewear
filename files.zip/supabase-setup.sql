-- TABLA DE PRODUCTOS
create table productos (
  id uuid default gen_random_uuid() primary key,
  nombre text not null,
  descripcion text,
  precio numeric not null,
  categoria text default 'Shorts',
  genero text default 'mujer',   -- 'mujer' o 'hombre'
  imagen_url text,
  colores text[],
  tallas text[],
  stock integer default 0,
  es_nuevo boolean default false,
  en_oferta boolean default false,
  precio_original numeric,
  created_at timestamp default now()
);

-- TABLA DE PEDIDOS
create table pedidos (
  id uuid default gen_random_uuid() primary key,
  nombre_cliente text not null,
  telefono text,
  email text,
  direccion text,
  items jsonb not null,
  total numeric not null,
  estado text default 'pendiente',
  created_at timestamp default now()
);

-- Permitir lectura pública de productos
alter table productos enable row level security;
create policy "Productos públicos" on productos for select using (true);
create policy "Admin puede todo en productos" on productos for all using (true);

-- Permitir insertar pedidos públicamente
alter table pedidos enable row level security;
create policy "Insertar pedidos" on pedidos for insert with check (true);
create policy "Admin puede ver pedidos" on pedidos for all using (true);

-- Datos de ejemplo - Mujer
insert into productos (nombre, descripcion, precio, categoria, genero, colores, tallas, stock, es_nuevo) values
('Short Curve Scrunch', 'Pretina Cruzada | Cintura Alta | Scrunch trasero', 18800, 'Shorts', 'mujer', ARRAY['#8b4513','#2c2c2c','#b0aaa3'], ARRAY['XS','S','M','L','XL'], 15, false),
('Short Aura Cross', 'Pretina Cruzada | Cintura Alta | Fit Medio', 18800, 'Shorts', 'mujer', ARRAY['#b0aaa3','#c0392b','#6b7c4a'], ARRAY['XS','S','M','L'], 20, false),
('Short Flame', 'Scrunch | Alto Impacto | Anti-Transparencia', 19500, 'Shorts', 'mujer', ARRAY['#c0392b','#2c2c2c'], ARRAY['XS','S','M','L','XL'], 10, true),
('Short Onyx', 'Pretina Doble | Cintura Extra Alta | Tiro Largo', 20000, 'Shorts', 'mujer', ARRAY['#2c2c2c','#2c4a7c'], ARRAY['S','M','L'], 8, false);

-- Datos de ejemplo - Hombre
insert into productos (nombre, descripcion, precio, categoria, genero, colores, tallas, stock, es_nuevo) values
('Short Athletic Pro', 'Tiro Medio | Bolsillos | Secado Rápido', 17500, 'Shorts', 'hombre', ARRAY['#2c2c2c','#2c4a7c','#6b7c4a'], ARRAY['S','M','L','XL','XXL'], 20, false),
('Tight Compression', 'Compresión Alta | Anti-Rozadura | 7/8', 21000, 'Leggings', 'hombre', ARRAY['#2c2c2c','#2c4a7c'], ARRAY['S','M','L','XL'], 12, true),
('Camiseta Dry Fit', 'Tejido Técnico | Sin Costuras | Ligera', 14500, 'Tops', 'hombre', ARRAY['#2c2c2c','#ffffff','#b0aaa3'], ARRAY['S','M','L','XL','XXL'], 25, false),
('Set Training Elite', 'Short + Camiseta | Outfit Completo', 32000, 'Sets', 'hombre', ARRAY['#2c2c2c','#2c4a7c'], ARRAY['S','M','L','XL'], 8, true);
